from django.db import models

# Create your models here.
class customer(models.Model):
    Username=models.CharField(max_length=30)
    Password=models.CharField(max_length=10)
    Firstname=models.CharField(max_length=30)
    Lastname=models.CharField(max_length=20)
    Place=models.CharField(max_length=30)
    Phone=models.CharField(max_length=12)
    Email=models.EmailField()
    class Meta:
        db_table="customer"

class food(models.Model):
    user_id=models.CharField(max_length=30)
    Food_name=models.CharField(max_length=100)
    Quantity=models.IntegerField()
    Category_id=models.IntegerField()
    Price=models.CharField(max_length=20)
    Photo=models.ImageField()
    class Meta:
        db_table="food"

class tables(models.Model):
    Table_id=models.CharField(max_length=30)
    user_id=models.CharField(max_length=30)
    Table_name=models.CharField(max_length=50)
    chair_count=models.IntegerField()
    Size=models.CharField(max_length=30)
    Time=models.CharField(max_length=30)
    Price=models.CharField(max_length=30)
    Image=models.ImageField()
    class Meta:
        db_table="tables"

class foodBooking(models.Model):
    user_id=models.CharField(max_length=30)
    Food_id=models.IntegerField()
    Food_name=models.CharField(max_length=100)
    Quantity=models.IntegerField()
    Price=models.CharField(max_length=30)
    status=models.CharField(max_length=30)
    class Meta:
        db_table="foodBooking"

class tableBooking(models.Model):
    Table_id=models.IntegerField()
    user_id=models.CharField(max_length=30)
    Table_name=models.CharField(max_length=50)
    Time=models.CharField(max_length=30)
    Price=models.CharField(max_length=30)
    status=models.CharField(max_length=30)
    class Meta:
        db_table="tableBooking"

class payment(models.Model):
    Booking_id=models.IntegerField()
    user_id=models.CharField(max_length=20)
    Amount=models.CharField(max_length=30)
    status=models.CharField(max_length=30)  
    class Meta:
        db_table="payment"

class foodpayment(models.Model):
    Booking_id=models.IntegerField()
    user_id=models.CharField(max_length=20)
    Amount=models.CharField(max_length=30)
    status=models.CharField(max_length=30)  
    class Meta:
        db_table="foodpayment"     

#food_category table 
class food_cat(models.Model):
    category_id=models.IntegerField()
    class Meta:
        db_table="food_cat"

