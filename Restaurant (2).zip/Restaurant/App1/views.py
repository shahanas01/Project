from django.shortcuts import render,redirect
from App1.models import customer,tables,tableBooking,food,foodBooking,payment,foodpayment
from django.http import HttpResponse
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.auth import logout

# Create your views here.
def home1(request):
    return render(request,'home1.html')
def home(request):
    return render(request,'index.html')
def adminhome(request):
    return render(request,'adminhome1.html')
def userhome(request):
    return render(request,'userhome1.html')
def userviewTable(request):
    return render(request,'userviewTable.html')
def userviewDishes(request):
    return render(request,'userviewDishes.html')
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')


def loginp(request):
    if request.method=="POST":
        u=request.POST['uname']
        p=request.POST['password']
        au=authenticate(username=u,password=p)
        print(au)
        request.session["user_id"]=u
        if au is not None and au.is_superuser==1:
            return render(request,"adminhome1.html")
        elif au is not None and au.is_superuser==0:
            return render(request,"userhome1.html")
        else:
            return HttpResponse('invalid user')
    return render(request,'login1.html')


def userReg(request):
    if request.method=='POST':
        a=request.POST['username']
        b=request.POST['pswd']
        c=request.POST['fname']
        d=request.POST['lname']
        e=request.POST['place']
        f=request.POST['phone']
        g=request.POST['email']
        p=customer(Username=a,Password=b,Firstname=c,Lastname=d,Place=e,Phone=f,Email=g)
        data=User(username=a)
        data.set_password(b)
        data.save()
        p.save()
        return HttpResponse('<script>alert("Successfully registerd"),window.location="/";</script>')
        
    return render(request,'userReg1.html')

def adminDishes(request):
    return render(request,'adminDishes1.html')

def addDishes(request):
    if request.method=='POST':
        a=request.POST['food_name']
        b=request.POST['quantity']
        c=request.POST['category_id']
        d=request.POST['price']
        e=request.FILES['image']
        p=food(Food_name=a,Quantity=b,Category_id=c,Price=d,Photo=e)
        p.save()
        return HttpResponse('<script>alert("Successfully Added"),window.location="/adminhome";</script>')
    return render(request,'addDishes.html')

# ##############
# def editDishes(request):
#     id=request.session['']
#     data02=food.objects.get(food=id)
#     if request.method=='POST':
#         data02.Username=request.POST['food_name']
#         data02.Password=request.POST['quantity']
#         data02.Firstname=request.POST['category_id']
#         data02.Lastname=request.POST['price']
#         data02.Place=request.FILES['image']
#         data02.save()
#         return HttpResponse('<script>alert("Successfully updated"),window.location="/adminhome";</script>')
#     return render(request,'updateDishes.html',{'y':data02})



def adminTable(request):
    return render(request,'adminTable.html')

def arrangetables(request):
    if request.method=='POST':
        a=request.POST['tablename']
        b=request.POST['chaircount']
        c=request.POST['size']
        d=request.POST['time']
        e=request.POST['price']
        f=request.FILES['image']
        p=tables(Table_name=a,chair_count=b,Size=c,Time=d,Price=e,Image=f,)
        p.save()
        return HttpResponse('<script>alert("Successfully registered"),window.location="/adminTable";</script>')
    return render(request,'tableReg.html')

def adminlogOut(request):
    logout(request)   
    return redirect('/')

def viewUsers(request):
    data=customer.objects.all()
    return render(request,'userupdate.html',{'x':data})


def update(request):
    id=request.session['user_id']
    data1=customer.objects.get(Username=id)
    if request.method=='POST':
        data1.Username=request.POST['username']
        data1.Password=request.POST['pswd']
        data1.Firstname=request.POST['fname']
        data1.Lastname=request.POST['lname']
        data1.Place=request.POST['place']
        data1.Phone=request.POST['phone']
        data1.Email=request.POST['email']
        data1.save()
        return HttpResponse('<script>alert("Successfully updated"),window.location="/userhome";</script>')
    return render(request,'userupdate1.html',{'y':data1})

def delete(request,id):
    data4=customer.objects.get(id=id)
    data4.delete()
    return HttpResponse('<script>alert("Successfully deleted"),window.location="/adminhome";</script>')


def reserveTable(request):
    return render(request,'userviewTable.html')

def bookTable(request):
    data01=tables.objects.all()
    return render(request,'bookTables.html',{'x':data01})

# codes to reserve(order) table:-

def orderreg(request,id,price,t):
    uid=request.session['user_id']
    oid=id
    pr=price
    time=t
    q=tables.objects.get(id=oid)
    tname=q.Table_name
    q1=tableBooking(Table_id=oid,user_id=uid,Table_name=tname,Time=time,Price=pr,status='pending')
    q1.save()
    return HttpResponse('<script>alert("Order Success"),window.location="/userviewTable";</script>')

def vieworderUser(request):
    uid=request.session['user_id']
    q=tableBooking.objects.filter(user_id=uid)
    return render(request,'vieworderUser.html',{'x':q})

def vieworderAdmin(request):
    q=tableBooking.objects.all()
    return render(request,'vieworderAdmin.html',{'x':q})

def order_approval(request,id):
    tid=id
    q=tableBooking.objects.get(id=tid)
    q.status="Approved"
    q.save()
    return HttpResponse('<script>alert("Successfully Approved"),window.location="/viewbooking";</script>')

def order_rejection(request,id):
    tid=id
    q=tableBooking.objects.get(id=tid)
    q.status="Rejected"
    q.save()
    return HttpResponse('<script>alert("Successfully Rejected"),window.location="/viewbooking";</script>')

def paymentRegistration(request,id,p):
    uid=request.session['user_id']
    tid=id
    price=p
    if request.method=='POST':
        amt=request.POST['amount']
        q=payment(Booking_id=tid,user_id=uid,Amount=amt,status="Paid")
        q.save()
        o=tableBooking.objects.get(id=tid)
        o.status="Paid"
        o.save()
        return HttpResponse('<script>alert("Payment Successful"),window.location="/trackBooking";</script>')
    return render(request,'paymentRegistration.html',{'pr':price})

def viewPay(request):
    q=payment.objects.all()
    return render(request,'viewPay.html',{'x':q})

# codes to order food:-

def userviewdishes(request):
    return render(request,'userviewDishes2.html')


def userviewDishes2(request):
    data05=food.objects.all()
    return render(request,'userviewDishes.html',{'x':data05})



def trackFoodorderuser(request):
    data01=tables.objects.all()
    return render(request,'userviewDishes2.html',{'x':data01})

def foodorderReg(request,id,price,q):
    uid=request.session['user_id']
    oid=id
    pr=price
    quantity=q
    q=food.objects.get(id=oid)
    fname=q.Food_name
    q1=foodBooking(user_id=uid,Food_id=oid,Food_name=fname,Quantity=quantity,Price=pr,status='pending')
    q1.save()
    return HttpResponse('<script>alert("Order Success"),window.location="/orderFood";</script>')

def trackFoodorderuser(request):
    uid=request.session['user_id']
    q=foodBooking.objects.filter(user_id=uid)
    return render(request,'viewFoodorderuser.html',{'x':q})

def trackFoodorderAdmin(request):
    q=foodBooking.objects.all()
    return render(request,'viewfoodorderAdmin1.html',{'x':q})

def foodorder_approval(request,id):
    fid=id
    q=foodBooking.objects.get(id=fid)
    q.status="Approved"
    q.save()
    return HttpResponse('<script>alert("Successfully Approved"),window.location="/viewbooking2";</script>')

def foodorder_rejection(request,id):
    fid=id
    q=foodBooking.objects.get(id=fid)
    q.status="Rejected"
    q.save()
    return HttpResponse('<script>alert("Successfully Rejected"),window.location="/viewbooking2";</script>')

def foodpaymentRegistration(request,id,p):
    uid=request.session['user_id']
    fid=id
    price=p
    if request.method=='POST':
        amt=request.POST['amount']
        q=foodpayment(Booking_id=fid,user_id=uid,Amount=amt,status="Paid")
        q.save()
        o=foodBooking.objects.get(id=fid)
        o.status="Paid"
        o.save()
        return HttpResponse('<script>alert("Payment Successful"),window.location="/trackFoodorder";</script>')
    return render(request,'foodpaymentRegistration.html',{'pr':price})

def foodviewPay(request):
    q=foodpayment.objects.all()
    return render(request,'foodviewPay.html',{'x':q})

def userlogOut(request):
    logout(request)   
    return redirect('/')










